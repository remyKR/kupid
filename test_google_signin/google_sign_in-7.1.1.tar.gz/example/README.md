# google_sign_in_example

Demonstrates how to use the google_sign_in plugin.
