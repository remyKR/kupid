# App configuration

Manual end-to-end testing of `google_sign_in` requires configuring the example
app with an active server-side GCP project. The example app currently has
placeholder information (in files such as Info.plist and google-services.json)
corresponding to a project that no longer exists, and there is currently no
active, team-managed test project.

Before running the example app, follow the
[README's platform integration instructions](./README.md#platform-integration)
for the platform(s) you are testing.
